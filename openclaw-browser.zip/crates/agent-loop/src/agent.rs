//! The main Agent struct — drives the observe→think→act loop.

use crate::{AgentConfig, BrowsingTask, error::AgentError, history::StepHistory, llm::LlmBackend};
use openclaw_browser_core::BrowserSession;
use tracing::{info, warn, error, debug, instrument};

/// The AI browsing agent. Owns a browser session and drives tasks to completion.
pub struct Agent<L: LlmBackend> {
    pub config: AgentConfig,
    pub session: BrowserSession,
    pub llm: L,
    pub history: StepHistory,
}

impl<L: LlmBackend> Agent<L> {
    pub fn new(config: AgentConfig, session: BrowserSession, llm: L) -> Self {
        Self {
            config,
            session,
            llm,
            history: StepHistory::new(),
        }
    }

    /// Run a browsing task to completion.
    #[instrument(skip(self), fields(task = %task.description))]
    pub async fn run(&mut self, task: BrowsingTask) -> Result<String, AgentError> {
        info!(
            task = %task.description,
            max_steps = self.config.max_steps,
            "Starting browsing task"
        );

        for step in 0..self.config.max_steps {
            info!(step, total_steps = self.config.max_steps, "Agent step");

            // 1. OBSERVE — snapshot the current page state
            let tab = self.session.active_tab().await
                .map_err(|e| AgentError::Browser(e))?;
            let snapshot = tab.snapshot().await
                .map_err(|e| AgentError::Browser(e))?;

            let observation = snapshot.to_agent_text();
            debug!(step, tokens = snapshot.estimated_tokens(), "Observation captured");

            // 2. THINK — ask the LLM what to do next
            self.history.add_observation(step, &observation);
            let messages = self.history.to_messages(&self.config.system_prompt, &task.description);
            let response = self.llm.complete(&messages, &self.config.model).await?;
            debug!(step, response_len = response.len(), "LLM response received");

            // 3. ACT — parse and execute the action
            self.history.add_action(step, &response);

            if let Some(result) = self.parse_terminal_action(&response) {
                info!(step, "Task completed");
                return Ok(result);
            }

            // TODO: Parse action from response, execute via tab.execute()
            // For now, just log the response
            info!(step, response = %response, "Action would be executed here");
        }

        Err(AgentError::MaxStepsExceeded {
            max_steps: self.config.max_steps,
        })
    }

    fn parse_terminal_action(&self, response: &str) -> Option<String> {
        for line in response.lines().rev() {
            let line = line.trim();
            if let Some(result) = line.strip_prefix("ACTION: done ") {
                return Some(result.trim_matches('"').to_string());
            }
            if let Some(reason) = line.strip_prefix("ACTION: fail ") {
                return Some(format!("FAILED: {}", reason.trim_matches('"')));
            }
        }
        None
    }
}
