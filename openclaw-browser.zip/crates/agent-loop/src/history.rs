//! Step history — tracks the observation→action pairs for the agent's conversation.

use crate::llm::{Message, MessageRole};

pub struct StepHistory {
    steps: Vec<Step>,
}

struct Step {
    step_num: usize,
    observation: String,
    action: Option<String>,
}

impl StepHistory {
    pub fn new() -> Self {
        Self { steps: vec![] }
    }

    pub fn add_observation(&mut self, step: usize, observation: &str) {
        self.steps.push(Step {
            step_num: step,
            observation: observation.to_string(),
            action: None,
        });
    }

    pub fn add_action(&mut self, step: usize, action: &str) {
        if let Some(s) = self.steps.iter_mut().find(|s| s.step_num == step) {
            s.action = Some(action.to_string());
        }
    }

    /// Convert history to LLM message format.
    pub fn to_messages(&self, system_prompt: &str, task: &str) -> Vec<Message> {
        let mut messages = vec![
            Message {
                role: MessageRole::System,
                content: system_prompt.to_string(),
            },
            Message {
                role: MessageRole::User,
                content: format!("Task: {}", task),
            },
        ];

        for step in &self.steps {
            messages.push(Message {
                role: MessageRole::User,
                content: format!("[Step {}] Observation:\n{}", step.step_num, step.observation),
            });
            if let Some(action) = &step.action {
                messages.push(Message {
                    role: MessageRole::Assistant,
                    content: action.clone(),
                });
            }
        }

        messages
    }
}
