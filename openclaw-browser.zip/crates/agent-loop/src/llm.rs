//! LLM backend trait — pluggable interface to any language model.
//! Supports Anthropic API, Ollama (local), OpenAI-compatible, etc.

use crate::error::AgentError;
use async_trait::async_trait;
use serde::{Deserialize, Serialize};

/// A message in the agent's conversation history.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Message {
    pub role: MessageRole,
    pub content: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum MessageRole {
    System,
    User,
    Assistant,
}

/// Trait for LLM backends. Implement this to plug in any model.
// NOTE: async_trait is needed until Rust stabilizes async fn in traits fully
// For now, implementors can use the async-trait crate or manual boxing
pub trait LlmBackend: Send + Sync {
    /// Send a conversation and get a completion response.
    fn complete(
        &self,
        messages: &[Message],
        model: &str,
    ) -> impl std::future::Future<Output = Result<String, AgentError>> + Send;
}

/// Anthropic Claude API backend.
pub struct ClaudeBackend {
    pub api_key: String,
    pub base_url: String,
}

/// Local Ollama backend (for OpenClaw fleet inference).
pub struct OllamaBackend {
    pub base_url: String,
}

// TODO: Implement LlmBackend for ClaudeBackend and OllamaBackend
