//! # Encrypted Credential Vault
//!
//! The vault stores all credentials in an SQLite database with each secret
//! individually encrypted using AES-256-GCM. The encryption key is derived
//! from a master passphrase using argon2id (memory-hard KDF).
//!
//! ## Key Derivation
//!
//! ```text
//! User passphrase ──► argon2id(salt, passphrase) ──► 256-bit master key
//!                                                         │
//!                    ┌────────────────────────────────────┘
//!                    │
//!                    ▼
//!              AES-256-GCM(master_key, unique_nonce, plaintext_secret)
//!                    │
//!                    ▼
//!              encrypted_blob stored in SQLite
//! ```
//!
//! ## File Security
//!
//! - Vault file: `~/.openclaw/vault.db` with 0600 permissions
//! - Salt stored alongside vault (not secret, just unique per vault)
//! - Master key NEVER written to disk — derived at unlock, held in memory
//! - On lock: master key zeroized, all decrypted credentials dropped

use std::path::{Path, PathBuf};
use std::sync::Arc;

use aes_gcm::{Aes256Gcm, KeyInit, Nonce};
use aes_gcm::aead::Aead;
use argon2::{Argon2, PasswordHasher, password_hash::SaltString};
use parking_lot::RwLock;
use rand::rngs::OsRng;
use secrecy::{SecretString, SecretVec, ExposeSecret};
use tracing::{info, warn, error, debug, instrument};
use zeroize::Zeroize;

use crate::credential::*;
use crate::error::*;

/// The encrypted credential vault.
pub struct CredentialVault {
    /// Path to the vault SQLite database
    db_path: PathBuf,

    /// SQLite connection
    db: Arc<parking_lot::Mutex<rusqlite::Connection>>,

    /// The derived master encryption key — None when locked.
    /// Wrapped in SecretVec for zeroize-on-drop.
    master_key: RwLock<Option<SecretVec<u8>>>,

    /// Salt for key derivation (stored in vault metadata)
    salt: String,

    /// Whether the vault is currently unlocked
    unlocked: RwLock<bool>,
}

impl CredentialVault {
    /// Open an existing vault or create a new one.
    /// The vault starts LOCKED — call `unlock()` before accessing credentials.
    #[instrument(fields(path = %path.as_ref().display()))]
    pub fn open(path: impl AsRef<Path>) -> IdentityResult<Self> {
        let db_path = path.as_ref().to_path_buf();
        let parent = db_path.parent().unwrap_or(Path::new("."));
        std::fs::create_dir_all(parent)
            .map_err(|e| IdentityError::Internal(anyhow::anyhow!("Failed to create vault dir: {}", e)))?;

        info!(path = %db_path.display(), "Opening credential vault");

        let conn = rusqlite::Connection::open(&db_path)?;
        conn.execute_batch("
            PRAGMA journal_mode=WAL;
            PRAGMA foreign_keys=ON;
        ")?;

        // Initialize schema
        conn.execute_batch(include_str!("sql/vault_schema.sql"))?;

        // Set file permissions (Unix only)
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let perms = std::fs::Permissions::from_mode(0o600);
            if let Err(e) = std::fs::set_permissions(&db_path, perms) {
                warn!(error = %e, "Failed to set vault file permissions to 0600");
            } else {
                debug!("Vault file permissions set to 0600 (owner-only)");
            }
        }

        // Get or create salt
        let salt = Self::get_or_create_salt(&conn)?;

        let vault = Self {
            db_path,
            db: Arc::new(parking_lot::Mutex::new(conn)),
            master_key: RwLock::new(None),
            salt,
            unlocked: RwLock::new(false),
        };

        info!("Credential vault opened (LOCKED — call unlock() to access credentials)");
        Ok(vault)
    }

    /// Create a new vault with a master passphrase.
    /// This sets the passphrase for the first time.
    #[instrument(skip(passphrase))]
    pub fn initialize(&self, passphrase: &SecretString) -> IdentityResult<()> {
        info!("Initializing vault with master passphrase");

        // Derive key from passphrase
        let key = self.derive_key(passphrase)?;

        // Store a verification token — encrypt a known value so we can
        // verify the passphrase is correct on unlock
        let verification = b"OPENCLAW_VAULT_V1";
        let encrypted = self.encrypt_bytes(&key, verification)?;

        let conn = self.db.lock();
        conn.execute(
            "INSERT OR REPLACE INTO vault_meta (key, value) VALUES ('verification', ?1)",
            rusqlite::params![base64::Engine::encode(&base64::engine::general_purpose::STANDARD, &encrypted)],
        )?;

        // Store the key in memory
        *self.master_key.write() = Some(key);
        *self.unlocked.write() = true;

        info!("Vault initialized and unlocked");
        Ok(())
    }

    /// Unlock the vault with the master passphrase.
    #[instrument(skip(passphrase))]
    pub fn unlock(&self, passphrase: &SecretString) -> IdentityResult<()> {
        info!("Unlocking credential vault");

        // Derive key from passphrase
        let key = self.derive_key(passphrase)?;

        // Verify against stored verification token
        let conn = self.db.lock();
        let encrypted_b64: Option<String> = conn.query_row(
            "SELECT value FROM vault_meta WHERE key = 'verification'",
            [],
            |row| row.get(0),
        ).ok();

        if let Some(encrypted_b64) = encrypted_b64 {
            let encrypted = base64::Engine::decode(
                &base64::engine::general_purpose::STANDARD,
                &encrypted_b64,
            ).map_err(|e| IdentityError::DecryptionFailed(e.to_string()))?;

            let decrypted = self.decrypt_bytes(&key, &encrypted)?;
            if decrypted != b"OPENCLAW_VAULT_V1" {
                warn!("Vault unlock failed — wrong passphrase");
                return Err(IdentityError::WrongPassphrase);
            }
        } else {
            // No verification token — vault needs initialization
            drop(conn);
            return self.initialize(passphrase);
        }

        drop(conn);

        *self.master_key.write() = Some(key);
        *self.unlocked.write() = true;

        let cred_count = self.list_credentials()?.len();
        info!(credentials = cred_count, "Vault unlocked successfully");
        Ok(())
    }

    /// Lock the vault — zeroize the master key from memory.
    #[instrument(skip(self))]
    pub fn lock(&self) {
        info!("Locking credential vault");
        *self.master_key.write() = None; // SecretVec handles zeroize on drop
        *self.unlocked.write() = false;
        info!("Vault locked — master key zeroized from memory");
    }

    pub fn is_unlocked(&self) -> bool {
        *self.unlocked.read()
    }

    /// Store a credential in the vault.
    #[instrument(skip(self, request), fields(domain = %request.domain, kind = ?request.kind))]
    pub fn store(&self, request: StoreCredentialRequest) -> IdentityResult<String> {
        self.require_unlocked()?;

        let key = self.get_key()?;
        let id = uuid::Uuid::new_v4().to_string();

        info!(
            id = %id,
            domain = %request.domain,
            kind = ?request.kind,
            identity = %request.identity,
            auto_use = request.auto_use,
            "Storing credential in vault"
        );

        // Encrypt the secret
        let secret_bytes = request.secret.expose_secret().as_bytes();
        let encrypted = self.encrypt_bytes(&key, secret_bytes)?;

        let conn = self.db.lock();
        conn.execute(
            "INSERT INTO credentials (
                id, domain, kind, identity, secret_encrypted,
                label, url_pattern, auto_use, metadata_json,
                created_at
            ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, datetime('now'))",
            rusqlite::params![
                id,
                request.domain,
                format!("{:?}", request.kind),
                request.identity,
                encrypted,
                request.label,
                request.url_pattern,
                request.auto_use,
                request.metadata.to_string(),
            ],
        )?;

        info!(id = %id, domain = %request.domain, "Credential stored");
        Ok(id)
    }

    /// Retrieve and decrypt a credential for a domain.
    #[instrument(skip(self), fields(domain = %domain))]
    pub fn get(
        &self,
        domain: &str,
        kind: Option<CredentialKind>,
    ) -> IdentityResult<DecryptedCredential> {
        self.require_unlocked()?;
        let key = self.get_key()?;

        debug!(domain = %domain, kind = ?kind, "Retrieving credential");

        let conn = self.db.lock();

        let (id, identity, encrypted, cred_kind): (String, String, Vec<u8>, String) = if let Some(k) = kind {
            conn.query_row(
                "SELECT id, identity, secret_encrypted, kind FROM credentials
                 WHERE domain = ?1 AND kind = ?2
                 ORDER BY last_used DESC NULLS LAST, created_at DESC
                 LIMIT 1",
                rusqlite::params![domain, format!("{:?}", k)],
                |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?)),
            ).map_err(|_| IdentityError::CredentialNotFound {
                domain: domain.to_string(),
                kind: format!("{:?}", k),
            })?
        } else {
            conn.query_row(
                "SELECT id, identity, secret_encrypted, kind FROM credentials
                 WHERE domain = ?1
                 ORDER BY last_used DESC NULLS LAST, created_at DESC
                 LIMIT 1",
                rusqlite::params![domain],
                |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?)),
            ).map_err(|_| IdentityError::CredentialNotFound {
                domain: domain.to_string(),
                kind: "any".to_string(),
            })?
        };

        // Update last_used and use_count
        conn.execute(
            "UPDATE credentials SET last_used = datetime('now'), use_count = use_count + 1 WHERE id = ?1",
            rusqlite::params![id],
        )?;

        drop(conn);

        // Decrypt the secret
        let decrypted_bytes = self.decrypt_bytes(&key, &encrypted)?;
        let secret_str = String::from_utf8(decrypted_bytes)
            .map_err(|e| IdentityError::DecryptionFailed(format!("UTF-8 decode: {}", e)))?;

        debug!(
            id = %id,
            domain = %domain,
            kind = %cred_kind,
            "Credential decrypted (secret in memory, will zeroize on drop)"
        );

        Ok(DecryptedCredential {
            id,
            domain: domain.to_string(),
            kind: kind.unwrap_or(CredentialKind::Generic),
            identity,
            secret: SecretString::from(secret_str),
        })
    }

    /// Generate a current TOTP code for a domain.
    #[instrument(skip(self), fields(domain = %domain))]
    pub fn generate_totp(&self, domain: &str) -> IdentityResult<String> {
        let seed_cred = self.get(domain, Some(CredentialKind::TotpSeed))?;
        let seed = seed_cred.expose_secret_value();

        debug!(domain = %domain, "Generating TOTP code");

        let totp = totp_rs::TOTP::new(
            totp_rs::Algorithm::SHA1,
            6,
            1,
            30,
            seed.as_bytes().to_vec(),
        ).map_err(|e| IdentityError::TotpFailed(e.to_string()))?;

        let code = totp.generate_current()
            .map_err(|e| IdentityError::TotpFailed(e.to_string()))?;

        info!(domain = %domain, "TOTP code generated (valid for ~30s)");
        Ok(code)
    }

    /// List all credentials (metadata only — secrets stay encrypted).
    pub fn list_credentials(&self) -> IdentityResult<Vec<CredentialSummary>> {
        let conn = self.db.lock();
        let mut stmt = conn.prepare(
            "SELECT id, domain, kind, identity, label, url_pattern,
                    auto_use, created_at, last_used, use_count
             FROM credentials ORDER BY domain, kind"
        )?;

        let results = stmt.query_map([], |row| {
            Ok(CredentialSummary {
                id: row.get(0)?,
                domain: row.get(1)?,
                kind: row.get(2)?,
                identity: row.get(3)?,
                label: row.get(4)?,
                url_pattern: row.get(5)?,
                auto_use: row.get(6)?,
                created_at: row.get(7)?,
                last_used: row.get(8)?,
                use_count: row.get(9)?,
            })
        })?.collect::<Result<Vec<_>, _>>()?;

        Ok(results)
    }

    /// Delete a credential by ID.
    #[instrument(skip(self), fields(id = %id))]
    pub fn delete(&self, id: &str) -> IdentityResult<()> {
        self.require_unlocked()?;
        info!(id = %id, "Deleting credential from vault");

        let conn = self.db.lock();
        let affected = conn.execute(
            "DELETE FROM credentials WHERE id = ?1",
            rusqlite::params![id],
        )?;

        if affected == 0 {
            return Err(IdentityError::CredentialNotFound {
                domain: "unknown".to_string(),
                kind: id.to_string(),
            });
        }

        info!(id = %id, "Credential deleted");
        Ok(())
    }

    // ═══════════════════════════════════════════════════════════════
    // INTERNAL CRYPTO
    // ═══════════════════════════════════════════════════════════════

    /// Derive a 256-bit encryption key from passphrase using argon2id.
    fn derive_key(&self, passphrase: &SecretString) -> IdentityResult<SecretVec<u8>> {
        debug!("Deriving encryption key with argon2id");

        let salt = SaltString::from_b64(&self.salt)
            .map_err(|e| IdentityError::EncryptionFailed(format!("Invalid salt: {}", e)))?;

        let argon2 = Argon2::default(); // argon2id with recommended params

        // Hash the passphrase — we extract the raw hash bytes as our AES key
        let hash = argon2
            .hash_password(passphrase.expose_secret().as_bytes(), &salt)
            .map_err(|e| IdentityError::EncryptionFailed(format!("Argon2 failed: {}", e)))?;

        let hash_bytes = hash.hash.ok_or_else(|| {
            IdentityError::EncryptionFailed("Argon2 produced no hash".to_string())
        })?;

        // Take first 32 bytes for AES-256
        let key_bytes: Vec<u8> = hash_bytes.as_bytes()[..32].to_vec();
        Ok(SecretVec::new(key_bytes))
    }

    /// Encrypt bytes with AES-256-GCM using a random nonce.
    /// Returns: nonce (12 bytes) || ciphertext
    fn encrypt_bytes(&self, key: &SecretVec<u8>, plaintext: &[u8]) -> IdentityResult<Vec<u8>> {
        let cipher = Aes256Gcm::new_from_slice(key.expose_secret())
            .map_err(|e| IdentityError::EncryptionFailed(e.to_string()))?;

        let nonce_bytes: [u8; 12] = rand::random();
        let nonce = Nonce::from_slice(&nonce_bytes);

        let ciphertext = cipher.encrypt(nonce, plaintext)
            .map_err(|e| IdentityError::EncryptionFailed(e.to_string()))?;

        // Prepend nonce to ciphertext
        let mut result = Vec::with_capacity(12 + ciphertext.len());
        result.extend_from_slice(&nonce_bytes);
        result.extend_from_slice(&ciphertext);

        Ok(result)
    }

    /// Decrypt bytes: expects nonce (12 bytes) || ciphertext.
    fn decrypt_bytes(&self, key: &SecretVec<u8>, data: &[u8]) -> IdentityResult<Vec<u8>> {
        if data.len() < 12 {
            return Err(IdentityError::DecryptionFailed("Data too short".to_string()));
        }

        let (nonce_bytes, ciphertext) = data.split_at(12);
        let cipher = Aes256Gcm::new_from_slice(key.expose_secret())
            .map_err(|e| IdentityError::DecryptionFailed(e.to_string()))?;
        let nonce = Nonce::from_slice(nonce_bytes);

        cipher.decrypt(nonce, ciphertext)
            .map_err(|e| IdentityError::DecryptionFailed(e.to_string()))
    }

    fn require_unlocked(&self) -> IdentityResult<()> {
        if !*self.unlocked.read() {
            Err(IdentityError::VaultLocked)
        } else {
            Ok(())
        }
    }

    fn get_key(&self) -> IdentityResult<SecretVec<u8>> {
        self.master_key
            .read()
            .as_ref()
            .map(|k| SecretVec::new(k.expose_secret().to_vec()))
            .ok_or(IdentityError::VaultLocked)
    }

    fn get_or_create_salt(conn: &rusqlite::Connection) -> IdentityResult<String> {
        let existing: Option<String> = conn.query_row(
            "SELECT value FROM vault_meta WHERE key = 'salt'",
            [],
            |row| row.get(0),
        ).ok();

        if let Some(salt) = existing {
            debug!("Using existing vault salt");
            Ok(salt)
        } else {
            let salt = SaltString::generate(&mut OsRng);
            let salt_str = salt.as_str().to_string();
            conn.execute(
                "INSERT INTO vault_meta (key, value) VALUES ('salt', ?1)",
                rusqlite::params![salt_str],
            )?;
            info!("Generated new vault salt");
            Ok(salt_str)
        }
    }
}

impl Drop for CredentialVault {
    fn drop(&mut self) {
        tracing::debug!("CredentialVault dropping — master key will be zeroized");
        // SecretVec handles zeroize automatically
    }
}

/// Summary of a credential (no secrets exposed).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CredentialSummary {
    pub id: String,
    pub domain: String,
    pub kind: String,
    pub identity: String,
    pub label: Option<String>,
    pub url_pattern: Option<String>,
    pub auto_use: bool,
    pub created_at: String,
    pub last_used: Option<String>,
    pub use_count: u64,
}
