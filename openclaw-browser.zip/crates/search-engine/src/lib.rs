//! # openclaw-search
//!
//! Dual-mode search engine for OpenClaw Browser:
//!
//! 1. **Web Metasearch** — Aggregates results from multiple search engines
//!    (Google, Bing, DuckDuckGo, Brave) with privacy-respecting defaults.
//!    Similar to SearXNG but native Rust.
//!
//! 2. **Local Index** — Tantivy-powered full-text index of browsed pages,
//!    extracted content, and agent session history. Enables "search my
//!    browsing history" and RAG-style context retrieval.

pub mod web;
pub mod local;
pub mod error;

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SearchResult {
    pub title: String,
    pub url: String,
    pub snippet: String,
    pub source: SearchSource,
    pub relevance_score: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SearchSource {
    Google,
    Bing,
    DuckDuckGo,
    Brave,
    LocalIndex,
}

/// Unified search interface.
pub async fn search(query: &str, max_results: usize) -> Result<Vec<SearchResult>, error::SearchError> {
    tracing::info!(query = %query, max_results, "Executing search");
    // TODO: Fan out to web metasearch + local index, merge + rank results
    Ok(vec![])
}
