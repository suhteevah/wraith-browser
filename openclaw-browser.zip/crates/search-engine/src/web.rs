//! Web metasearch — aggregates results from multiple search providers.
//! TODO: Implement provider adapters for Google, Bing, DuckDuckGo, Brave
//! Reference: Websurfx project architecture

use crate::{SearchResult, error::SearchError};
use tracing::instrument;

#[instrument(skip_all, fields(query = %query))]
pub async fn metasearch(query: &str, max_results: usize) -> Result<Vec<SearchResult>, SearchError> {
    tracing::info!(query = %query, "Running web metasearch");
    // TODO: Fan out to multiple providers concurrently
    Ok(vec![])
}
