//! Tantivy full-text index wrapper.

use crate::error::{CacheError, CacheResult};
use std::path::Path;
use tracing::{info, debug, instrument};

/// Tantivy-backed full-text search index.
pub struct FulltextIndex {
    // TODO: tantivy::Index handle
    index_path: std::path::PathBuf,
}

/// A raw search hit from Tantivy (before enrichment from SQLite).
pub struct FulltextHit {
    pub url: String,
    pub title: String,
    pub snippet: String,
    pub score: f32,
}

impl FulltextIndex {
    pub fn open(path: &Path) -> CacheResult<Self> {
        std::fs::create_dir_all(path)
            .map_err(|e| CacheError::IndexError(format!("Failed to create index dir: {}", e)))?;
        info!(path = %path.display(), "Tantivy fulltext index opened");
        Ok(Self { index_path: path.to_path_buf() })
    }

    #[instrument(skip(self, plain_text), fields(url = %url))]
    pub fn index_page(
        &self,
        url_hash: &str,
        url: &str,
        title: &str,
        plain_text: &str,
        snippet: &str,
        tags: &[String],
    ) -> CacheResult<()> {
        debug!(url = %url, text_len = plain_text.len(), "Indexing page in Tantivy");
        // TODO: Add document to Tantivy index
        Ok(())
    }

    pub fn index_search_result(
        &self,
        query_hash: &str,
        query: &str,
        title: &str,
        snippet: &str,
        url: &str,
    ) -> CacheResult<()> {
        debug!(query = %query, url = %url, "Indexing search result in Tantivy");
        // TODO: Add to Tantivy
        Ok(())
    }

    #[instrument(skip(self), fields(query = %query))]
    pub fn search(&self, query: &str, max_results: usize) -> CacheResult<Vec<FulltextHit>> {
        debug!(query = %query, max = max_results, "Searching Tantivy index");
        // TODO: Execute Tantivy query
        Ok(vec![])
    }
}
