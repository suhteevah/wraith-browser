use std::path::{Path, PathBuf};
use std::sync::Arc;
use parking_lot::Mutex;
use tracing::{info, warn, debug, error, instrument};
use chrono::Utc;

use crate::error::{CacheError, CacheResult};
use crate::schema::*;
use crate::staleness::StalenessPolicy;
use crate::query::{CacheQuery, CacheResult as QueryResult};
use crate::compression;
use crate::fulltext::FulltextIndex;

/// The central knowledge store. Every agent operation flows through here.
///
/// Usage pattern from browser-core:
/// ```text
/// // Before fetching a URL:
/// match store.get_page(url).await? {
///     Some(page) if !store.is_stale(&page) => return Ok(page),  // Cache hit!
///     _ => { /* fetch from web, then store.put_page(...) */ }
/// }
/// ```
pub struct KnowledgeStore {
    /// SQLite connection (single writer, multiple readers via WAL mode)
    db: Arc<Mutex<rusqlite::Connection>>,

    /// Tantivy full-text index for content search
    fulltext: FulltextIndex,

    /// Base directory for blob storage (compressed HTML, screenshots)
    blob_dir: PathBuf,

    /// Staleness policy configuration
    staleness: StalenessPolicy,
}

impl KnowledgeStore {
    /// Open or create a knowledge store at the given directory.
    #[instrument(fields(path = %path.as_ref().display()))]
    pub fn open(path: impl AsRef<Path>) -> CacheResult<Self> {
        let base = path.as_ref().to_path_buf();
        std::fs::create_dir_all(&base)
            .map_err(|e| CacheError::IoError(format!("Failed to create store dir: {}", e)))?;

        let db_path = base.join("knowledge.db");
        let blob_dir = base.join("blobs");
        let index_dir = base.join("index");

        std::fs::create_dir_all(&blob_dir)
            .map_err(|e| CacheError::IoError(format!("Failed to create blob dir: {}", e)))?;

        info!(
            db_path = %db_path.display(),
            blob_dir = %blob_dir.display(),
            index_dir = %index_dir.display(),
            "Opening KnowledgeStore"
        );

        // Open SQLite with WAL mode for concurrent reads
        let conn = rusqlite::Connection::open(&db_path)
            .map_err(|e| CacheError::DatabaseError(e.to_string()))?;

        conn.execute_batch("
            PRAGMA journal_mode=WAL;
            PRAGMA synchronous=NORMAL;
            PRAGMA cache_size=-64000;
            PRAGMA foreign_keys=ON;
            PRAGMA busy_timeout=5000;
        ").map_err(|e| CacheError::DatabaseError(e.to_string()))?;

        let db = Arc::new(Mutex::new(conn));

        // Initialize schema
        Self::init_schema(&db)?;

        // Open or create Tantivy index
        let fulltext = FulltextIndex::open(&index_dir)?;

        let store = Self {
            db,
            fulltext,
            blob_dir,
            staleness: StalenessPolicy::default(),
        };

        let stats = store.stats()?;
        info!(
            pages = stats.total_pages,
            searches = stats.total_searches,
            snapshots = stats.total_snapshots,
            domains = stats.total_domains,
            disk_bytes = stats.total_disk_bytes,
            "KnowledgeStore opened"
        );

        Ok(store)
    }

    /// Initialize the SQLite schema.
    fn init_schema(db: &Arc<Mutex<rusqlite::Connection>>) -> CacheResult<()> {
        let conn = db.lock();
        conn.execute_batch(include_str!("sql/schema.sql"))
            .map_err(|e| CacheError::DatabaseError(format!("Schema init failed: {}", e)))?;
        debug!("Database schema initialized");
        Ok(())
    }

    // ═══════════════════════════════════════════════════════════════
    // PAGE CACHE — the primary knowledge store
    // ═══════════════════════════════════════════════════════════════

    /// Look up a cached page by URL. Returns None on cache miss.
    #[instrument(skip(self), fields(url = %url))]
    pub fn get_page(&self, url: &str) -> CacheResult<Option<CachedPage>> {
        let url_hash = Self::hash_url(url);
        debug!(url_hash = %url_hash, "Looking up cached page");

        let conn = self.db.lock();
        // TODO: SELECT from pages WHERE url_hash = ?
        // If found, increment hit_count
        // Return deserialized CachedPage

        debug!(url = %url, "Cache miss (stub implementation)");
        Ok(None)
    }

    /// Store a page in the cache. Compresses and stores raw HTML as a blob,
    /// indexes markdown content in Tantivy, updates domain profile.
    #[instrument(skip(self, page, raw_html), fields(url = %page.url, content_type = ?page.content_type))]
    pub fn put_page(&self, page: &CachedPage, raw_html: &str) -> CacheResult<()> {
        info!(
            url = %page.url,
            domain = %page.domain,
            content_type = ?page.content_type,
            token_count = page.token_count,
            links = page.links.len(),
            "Caching page"
        );

        // 1. Compress and store raw HTML blob
        let compressed = compression::compress(raw_html.as_bytes())?;
        let blob_path = self.blob_dir.join(&page.url_hash);
        std::fs::write(&blob_path, &compressed)
            .map_err(|e| CacheError::IoError(format!("Blob write failed: {}", e)))?;
        debug!(
            original_size = raw_html.len(),
            compressed_size = compressed.len(),
            ratio = format!("{:.1}%", compressed.len() as f64 / raw_html.len() as f64 * 100.0),
            "Raw HTML compressed and stored"
        );

        // 2. Insert/update SQLite row
        {
            let conn = self.db.lock();
            // TODO: INSERT OR REPLACE INTO pages (...)
            // Store all CachedPage fields
            // Update domain profile
            debug!("Page metadata stored in SQLite");
        }

        // 3. Index in Tantivy for full-text search
        self.fulltext.index_page(
            &page.url_hash,
            &page.url,
            &page.title,
            &page.plain_text,
            &page.snippet,
            &page.tags,
        )?;
        debug!("Page indexed in Tantivy");

        // 4. Update domain profile
        self.update_domain_profile(&page.domain, page)?;

        info!(
            url = %page.url,
            total_stored_bytes = compressed.len(),
            "Page cached successfully"
        );

        Ok(())
    }

    /// Check if a cached page is stale (needs re-fetch).
    #[instrument(skip(self, page), fields(url = %page.url))]
    pub fn is_stale(&self, page: &CachedPage) -> bool {
        if page.pinned {
            debug!(url = %page.url, "Page is pinned — never stale");
            return false;
        }

        // Check domain-specific TTL override first
        let ttl_secs = self.get_effective_ttl(&page.domain, page.content_type);
        let age_secs = (Utc::now() - page.last_fetched).num_seconds() as u64;
        let stale = age_secs > ttl_secs;

        debug!(
            url = %page.url,
            age_secs,
            ttl_secs,
            content_type = ?page.content_type,
            stale,
            "Staleness check"
        );

        stale
    }

    /// Get the raw HTML for a cached page (decompresses from blob store).
    #[instrument(skip(self), fields(url_hash = %url_hash))]
    pub fn get_raw_html(&self, url_hash: &str) -> CacheResult<Option<String>> {
        let blob_path = self.blob_dir.join(url_hash);
        if !blob_path.exists() {
            return Ok(None);
        }

        let compressed = std::fs::read(&blob_path)
            .map_err(|e| CacheError::IoError(format!("Blob read failed: {}", e)))?;
        let decompressed = compression::decompress(&compressed)?;
        let html = String::from_utf8(decompressed)
            .map_err(|e| CacheError::IoError(format!("UTF-8 decode failed: {}", e)))?;

        debug!(url_hash = %url_hash, html_len = html.len(), "Raw HTML retrieved from blob store");
        Ok(Some(html))
    }

    // ═══════════════════════════════════════════════════════════════
    // SEARCH CACHE — metasearch result caching
    // ═══════════════════════════════════════════════════════════════

    /// Look up cached search results for a query.
    /// Uses normalized query matching — "rust web browser" matches "web browser rust".
    #[instrument(skip(self), fields(query = %query))]
    pub fn get_search(&self, query: &str) -> CacheResult<Option<CachedSearch>> {
        let normalized = Self::normalize_query(query);
        let query_hash = Self::hash_query(&normalized);
        debug!(query = %query, normalized = %normalized, query_hash = %query_hash, "Looking up cached search");

        let conn = self.db.lock();
        // TODO: SELECT from searches WHERE query_hash = ?
        // Check staleness (search results use SearchResults TTL)
        // If stale, return None (forces re-search)

        Ok(None)
    }

    /// Store search results in the cache.
    #[instrument(skip(self, results), fields(query = %results.query, result_count = results.results.len()))]
    pub fn put_search(&self, results: &CachedSearch) -> CacheResult<()> {
        info!(
            query = %results.query,
            results = results.results.len(),
            providers = ?results.providers_used,
            duration_ms = results.search_duration_ms,
            "Caching search results"
        );

        let conn = self.db.lock();
        // TODO: INSERT OR REPLACE INTO searches (...)

        // Also index each search result snippet in Tantivy
        // so agents can find relevant cached searches by content
        for result in &results.results {
            self.fulltext.index_search_result(
                &results.query_hash,
                &results.query,
                &result.title,
                &result.snippet,
                &result.url,
            )?;
        }

        Ok(())
    }

    // ═══════════════════════════════════════════════════════════════
    // SNAPSHOT CACHE — agent session memory
    // ═══════════════════════════════════════════════════════════════

    /// Store a DOM snapshot for an agent session.
    #[instrument(skip(self, snapshot), fields(session = %snapshot.session_id, step = snapshot.step))]
    pub fn put_snapshot(&self, snapshot: &CachedSnapshot) -> CacheResult<()> {
        debug!(
            session = %snapshot.session_id,
            step = snapshot.step,
            url = %snapshot.url,
            elements = snapshot.element_count,
            "Caching DOM snapshot"
        );

        let conn = self.db.lock();
        // TODO: INSERT INTO snapshots (...)
        Ok(())
    }

    /// Retrieve snapshots for a session, optionally filtered by step range.
    #[instrument(skip(self), fields(session = %session_id))]
    pub fn get_snapshots(
        &self,
        session_id: &str,
        from_step: Option<usize>,
        to_step: Option<usize>,
    ) -> CacheResult<Vec<CachedSnapshot>> {
        debug!(
            session = %session_id,
            from = ?from_step,
            to = ?to_step,
            "Retrieving session snapshots"
        );

        // TODO: SELECT from snapshots WHERE session_id = ? AND step BETWEEN ? AND ?
        Ok(vec![])
    }

    // ═══════════════════════════════════════════════════════════════
    // AI SEARCH — the killer feature
    // ═══════════════════════════════════════════════════════════════

    /// Search the entire knowledge store — pages, search results, snapshots.
    /// This is what makes OpenClaw different from SearXNG: the agent can
    /// search everything it has ever seen, not just the web.
    ///
    /// Returns results ranked by relevance, with cache metadata so the agent
    /// knows what's fresh and what might need re-fetching.
    #[instrument(skip(self), fields(query = %query, max_results))]
    pub fn search_knowledge(
        &self,
        query: &str,
        max_results: usize,
    ) -> CacheResult<Vec<QueryResult>> {
        info!(query = %query, max_results, "Searching knowledge store");

        // 1. Full-text search via Tantivy
        let tantivy_results = self.fulltext.search(query, max_results * 2)?;
        debug!(tantivy_hits = tantivy_results.len(), "Tantivy search complete");

        // 2. Enrich with SQLite metadata (staleness, hit count, etc.)
        let mut results: Vec<QueryResult> = Vec::new();
        {
            let conn = self.db.lock();
            for hit in tantivy_results {
                // TODO: JOIN tantivy results with SQLite page metadata
                // Compute staleness, add domain profile info
                results.push(QueryResult {
                    url: hit.url,
                    title: hit.title,
                    snippet: hit.snippet,
                    relevance_score: hit.score,
                    is_stale: false,     // TODO: compute
                    age_secs: 0,         // TODO: compute
                    hit_count: 0,        // TODO: from SQLite
                    content_type: ContentType::Generic,
                    token_count: 0,
                    source: crate::query::KnowledgeSource::CachedPage,
                });
            }
        }

        // 3. Sort by relevance, dedup, limit
        results.sort_by(|a, b| b.relevance_score.partial_cmp(&a.relevance_score).unwrap_or(std::cmp::Ordering::Equal));
        results.truncate(max_results);

        info!(
            query = %query,
            results = results.len(),
            stale_count = results.iter().filter(|r| r.is_stale).count(),
            "Knowledge search complete"
        );

        Ok(results)
    }

    /// Semantic similarity search — finds pages similar to a given URL.
    /// Useful for: "find me pages related to what I'm looking at now"
    #[instrument(skip(self), fields(url = %url))]
    pub fn find_similar(&self, url: &str, max_results: usize) -> CacheResult<Vec<QueryResult>> {
        debug!(url = %url, "Finding similar cached pages");
        // TODO: Use the page's content to query Tantivy
        // More-Like-This style search
        Ok(vec![])
    }

    // ═══════════════════════════════════════════════════════════════
    // DOMAIN PROFILES — adaptive staleness
    // ═══════════════════════════════════════════════════════════════

    /// Get or create a domain profile.
    pub fn get_domain_profile(&self, domain: &str) -> CacheResult<Option<DomainProfile>> {
        let conn = self.db.lock();
        // TODO: SELECT from domain_profiles WHERE domain = ?
        Ok(None)
    }

    /// Update domain profile with new page observation.
    fn update_domain_profile(&self, domain: &str, page: &CachedPage) -> CacheResult<()> {
        debug!(domain = %domain, "Updating domain profile");
        // TODO: UPSERT domain_profiles
        // If page existed before, check if content_hash changed
        // If changed, update avg_change_interval_secs
        // Recompute computed_ttl_secs
        Ok(())
    }

    /// Get effective TTL for a domain + content type.
    fn get_effective_ttl(&self, domain: &str, content_type: ContentType) -> u64 {
        // Priority: domain override > domain computed > content type default
        if let Ok(Some(profile)) = self.get_domain_profile(domain) {
            if let Some(override_ttl) = profile.override_ttl_secs {
                return override_ttl;
            }
            if profile.computed_ttl_secs > 0 {
                return profile.computed_ttl_secs;
            }
        }
        content_type.default_ttl_secs()
    }

    // ═══════════════════════════════════════════════════════════════
    // AGENT OPERATIONS — high-level convenience methods
    // ═══════════════════════════════════════════════════════════════

    /// Pin a URL — marks it as never-expire in the cache.
    /// Agents use this for important reference pages.
    #[instrument(skip(self), fields(url = %url))]
    pub fn pin_page(&self, url: &str, notes: Option<&str>) -> CacheResult<()> {
        info!(url = %url, notes = ?notes, "Pinning page (never expires)");
        let url_hash = Self::hash_url(url);
        let conn = self.db.lock();
        // TODO: UPDATE pages SET pinned = 1, agent_notes = ? WHERE url_hash = ?
        Ok(())
    }

    /// Tag a cached page for organization.
    #[instrument(skip(self), fields(url = %url))]
    pub fn tag_page(&self, url: &str, tags: &[&str]) -> CacheResult<()> {
        debug!(url = %url, tags = ?tags, "Tagging page");
        let url_hash = Self::hash_url(url);
        let conn = self.db.lock();
        // TODO: UPDATE pages SET tags = json(?) WHERE url_hash = ?
        Ok(())
    }

    /// Purge stale entries from the cache.
    #[instrument(skip(self))]
    pub fn purge_stale(&self) -> CacheResult<u64> {
        info!("Purging stale cache entries");
        // TODO: DELETE from pages WHERE stale AND NOT pinned
        // Also remove blob files and Tantivy docs
        Ok(0)
    }

    /// Evict entries to stay under a storage budget.
    #[instrument(skip(self), fields(max_bytes))]
    pub fn evict_to_budget(&self, max_bytes: u64) -> CacheResult<u64> {
        info!(max_bytes, "Evicting to storage budget");
        // TODO: LRU eviction based on hit_count and last_fetched
        // Never evict pinned pages
        Ok(0)
    }

    // ═══════════════════════════════════════════════════════════════
    // UTILITIES
    // ═══════════════════════════════════════════════════════════════

    /// Hash a URL to produce a cache key. Normalizes before hashing.
    pub fn hash_url(url: &str) -> String {
        let normalized = Self::normalize_url(url);
        blake3::hash(normalized.as_bytes()).to_hex().to_string()
    }

    /// Hash a search query.
    pub fn hash_query(normalized_query: &str) -> String {
        blake3::hash(normalized_query.as_bytes()).to_hex().to_string()
    }

    /// Normalize a URL: remove tracking params, fragments, trailing slashes.
    pub fn normalize_url(url: &str) -> String {
        // TODO: Full URL normalization
        // - Remove utm_*, fbclid, gclid, ref, etc.
        // - Remove fragment (#...)
        // - Remove trailing slash
        // - Lowercase scheme and host
        // - Sort remaining query params
        url.split('#').next().unwrap_or(url)
            .trim_end_matches('/')
            .to_lowercase()
    }

    /// Normalize a search query: lowercase, remove stopwords, sort words.
    pub fn normalize_query(query: &str) -> String {
        let mut words: Vec<&str> = query
            .to_lowercase()
            .split_whitespace()
            .filter(|w| !STOP_WORDS.contains(w))
            .collect();
        // DON'T sort — word order matters for phrase-like queries
        // But do normalize spacing
        query.to_lowercase().split_whitespace().collect::<Vec<_>>().join(" ")
    }

    /// Get cache statistics.
    pub fn stats(&self) -> CacheResult<CacheStats> {
        let conn = self.db.lock();
        // TODO: Aggregate counts from all tables
        Ok(CacheStats::default())
    }
}

/// Cache statistics for monitoring and display.
#[derive(Debug, Default)]
pub struct CacheStats {
    pub total_pages: u64,
    pub total_searches: u64,
    pub total_snapshots: u64,
    pub total_domains: u64,
    pub total_disk_bytes: u64,
    pub total_cache_hits: u64,
    pub stale_pages: u64,
    pub pinned_pages: u64,
    pub avg_page_age_secs: u64,
}

const STOP_WORDS: &[&str] = &[
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "shall", "to", "of", "in", "for",
    "on", "with", "at", "by", "from", "as", "into", "through", "during",
    "before", "after", "above", "below", "between", "and", "but", "or",
    "not", "no", "nor", "so", "if", "then", "than", "too", "very",
    "just", "about", "also", "it", "its", "this", "that", "these", "those",
];
