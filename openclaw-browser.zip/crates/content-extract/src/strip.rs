//! HTML noise stripping — removes scripts, styles, ads, trackers before extraction.
//! Uses lol_html for streaming performance.

use crate::error::ExtractError;

/// Strip scripts, styles, iframes, and known ad/tracker patterns from HTML.
pub fn strip_noise(html: &str) -> Result<String, ExtractError> {
    tracing::debug!(html_len = html.len(), "Stripping noise from HTML");
    // TODO: Use lol_html to stream-strip:
    // - <script> tags
    // - <style> tags
    // - <iframe> tags
    // - <noscript> tags
    // - Hidden elements (display:none, visibility:hidden)
    // - Known ad container class patterns
    // - Tracking pixels
    Ok(html.to_string())
}
