//! HTML to Markdown conversion optimized for LLM consumption.
//! TODO: Implement turndown.js-style conversion (reference: htmd crate)

use crate::error::ExtractError;

/// Convert HTML to markdown.
pub fn html_to_markdown(html: &str) -> Result<String, ExtractError> {
    tracing::debug!(html_len = html.len(), "Converting HTML to markdown");
    // TODO: Implement proper HTML→Markdown conversion
    // Reference crates: htmd, fast_html2md
    Ok(html.to_string())
}

/// Convert HTML to plain text (no formatting).
pub fn html_to_plain_text(html: &str) -> Result<String, ExtractError> {
    // TODO: Strip all HTML tags, decode entities
    Ok(html.to_string())
}
