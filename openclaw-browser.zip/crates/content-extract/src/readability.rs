//! Readability algorithm — extracts main article content from HTML.
//! TODO: Implement Mozilla Readability algorithm in pure Rust.
//! Reference: dom_smoothie crate, readability.js

use crate::error::ExtractError;

pub struct Article {
    pub title: String,
    pub content: String,
    pub links: Vec<(String, String)>,
    pub images: Vec<(String, String)>,
    pub description: Option<String>,
    pub confidence: f32,
}

/// Extract the main article content from cleaned HTML.
pub fn extract_article(html: &str, url: &str) -> Result<Article, ExtractError> {
    tracing::debug!(url = %url, "Running readability extraction");
    // TODO: Implement readability scoring algorithm
    // For now, return the full HTML as content
    Ok(Article {
        title: "Untitled".to_string(),
        content: html.to_string(),
        links: vec![],
        images: vec![],
        description: None,
        confidence: 0.0,
    })
}
