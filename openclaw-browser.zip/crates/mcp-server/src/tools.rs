//! MCP tool definitions for OpenClaw Browser.
//! Each tool maps to browser-core actions with AI-friendly input/output schemas.

use serde::{Deserialize, Serialize};

// TODO: Implement each tool using rmcp's tool registration API.
// Each tool should:
// 1. Validate inputs
// 2. Log the action with tracing
// 3. Execute via BrowserSession
// 4. Return structured JSON response
// 5. Include annotations (readOnlyHint, destructiveHint, etc.)

/// Tool: navigate to a URL and return a DOM snapshot
#[derive(Debug, Deserialize)]
pub struct NavigateInput {
    pub url: String,
    /// Wait for page load before returning snapshot (default: true)
    pub wait_for_load: Option<bool>,
}

#[derive(Debug, Serialize)]
pub struct NavigateOutput {
    pub url: String,
    pub title: String,
    pub snapshot: String,
    pub page_type: Option<String>,
    pub interactive_elements: usize,
}

/// Tool: click an element
#[derive(Debug, Deserialize)]
pub struct ClickInput {
    /// Element ref ID from snapshot (e.g., 5 for @e5)
    pub ref_id: u32,
}

/// Tool: fill a form field
#[derive(Debug, Deserialize)]
pub struct FillInput {
    pub ref_id: u32,
    pub text: String,
}

/// Tool: extract content as markdown
#[derive(Debug, Deserialize)]
pub struct ExtractInput {
    /// Maximum tokens for the extracted content
    pub max_tokens: Option<usize>,
}

#[derive(Debug, Serialize)]
pub struct ExtractOutput {
    pub title: String,
    pub markdown: String,
    pub estimated_tokens: usize,
    pub links_count: usize,
}

/// Tool: search the web
#[derive(Debug, Deserialize)]
pub struct SearchInput {
    pub query: String,
    pub max_results: Option<usize>,
}

/// Tool: run an autonomous browsing task
#[derive(Debug, Deserialize)]
pub struct TaskInput {
    pub description: String,
    pub start_url: Option<String>,
    pub max_steps: Option<usize>,
}

#[derive(Debug, Serialize)]
pub struct TaskOutput {
    pub result: String,
    pub steps_taken: usize,
    pub urls_visited: Vec<String>,
}
