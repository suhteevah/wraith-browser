//! MCP server initialization and tool registration.

use tracing::info;

/// Register all OpenClaw Browser tools with the MCP server.
pub fn register_tools() {
    info!("Registering OpenClaw Browser MCP tools");
    // TODO: Use rmcp to register each tool:
    // - browse_navigate
    // - browse_click
    // - browse_fill
    // - browse_snapshot
    // - browse_extract
    // - browse_screenshot
    // - browse_search
    // - browse_eval_js
    // - browse_tabs
    // - browse_back
    // - browse_task
    info!("All MCP tools registered");
}
