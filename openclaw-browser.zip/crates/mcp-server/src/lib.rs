//! # openclaw-mcp-server
//!
//! MCP (Model Context Protocol) server that exposes OpenClaw Browser
//! capabilities as tools for Claude Code, Cursor, and other AI agents.
//!
//! ## Tools Exposed
//!
//! | Tool | Description |
//! |------|-------------|
//! | `browse_navigate` | Navigate to a URL, return DOM snapshot |
//! | `browse_click` | Click an element by @ref ID |
//! | `browse_fill` | Fill a form field by @ref ID |
//! | `browse_snapshot` | Get current page DOM snapshot |
//! | `browse_extract` | Extract page content as markdown |
//! | `browse_screenshot` | Capture page screenshot |
//! | `browse_search` | Web metasearch |
//! | `browse_eval_js` | Execute JavaScript on the page |
//! | `browse_tabs` | List open tabs |
//! | `browse_back` | Go back in history |
//! | `browse_task` | Run an autonomous browsing task |
//!
//! ## Transport
//!
//! Supports both stdio (for Claude Code) and SSE (for remote agents).

pub mod tools;
pub mod server;

use tracing::info;

/// Start the MCP server with the given transport mode.
pub async fn run(transport: Transport) -> anyhow::Result<()> {
    info!(transport = ?transport, "Starting OpenClaw MCP Server");

    match transport {
        Transport::Stdio => {
            info!("MCP server running on stdio");
            // TODO: rmcp stdio transport
        }
        Transport::Sse { host, port } => {
            info!(host = %host, port, "MCP server running on SSE");
            // TODO: rmcp SSE transport via axum
        }
    }

    Ok(())
}

#[derive(Debug, Clone)]
pub enum Transport {
    Stdio,
    Sse { host: String, port: u16 },
}
