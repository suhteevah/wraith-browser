use anyhow::Context;
use clap::{Parser, Subcommand};
use tracing::{info, error};

#[derive(Parser)]
#[command(
    name = "openclaw-browser",
    about = "OpenClaw Browser — an AI-agent-first web browser written in Rust",
    version,
    long_about = "A native Rust web browser designed for AI agent control, not humans.\n\
                   Supports MCP for Claude Code integration, autonomous browsing tasks,\n\
                   SearXNG-style metasearch, and optimized content extraction for LLMs."
)]
struct Cli {
    #[command(subcommand)]
    command: Commands,

    /// Enable verbose logging
    #[arg(short, long, global = true)]
    verbose: bool,
}

#[derive(Subcommand)]
enum Commands {
    /// Start the MCP server (stdio or SSE transport)
    Serve {
        /// Transport mode: "stdio" or "sse"
        #[arg(short, long, default_value = "stdio")]
        transport: String,

        /// Host for SSE transport
        #[arg(long, default_value = "127.0.0.1")]
        host: String,

        /// Port for SSE transport
        #[arg(short, long, default_value = "3100")]
        port: u16,
    },

    /// Navigate to a URL and print the DOM snapshot
    Navigate {
        /// URL to navigate to
        url: String,

        /// Output format: "snapshot", "markdown", "json"
        #[arg(short, long, default_value = "snapshot")]
        format: String,
    },

    /// Run an autonomous browsing task
    Task {
        /// Task description
        description: String,

        /// Starting URL
        #[arg(short, long)]
        url: Option<String>,

        /// Maximum steps
        #[arg(long, default_value = "50")]
        max_steps: usize,
    },

    /// Search the web
    Search {
        /// Search query
        query: String,

        /// Maximum results
        #[arg(short, long, default_value = "10")]
        max_results: usize,
    },

    /// Extract readable content from a URL
    Extract {
        /// URL to extract content from
        url: String,

        /// Maximum token budget
        #[arg(long, default_value = "4000")]
        max_tokens: usize,
    },
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();

    // Initialize tracing
    let filter = if cli.verbose {
        "openclaw=trace,tower_http=debug"
    } else {
        "openclaw=info,tower_http=warn"
    };

    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| filter.into()),
        )
        .with_target(true)
        .with_thread_ids(true)
        .with_file(true)
        .with_line_number(true)
        .init();

    info!(
        version = env!("CARGO_PKG_VERSION"),
        "OpenClaw Browser starting"
    );

    match cli.command {
        Commands::Serve { transport, host, port } => {
            let transport = match transport.as_str() {
                "stdio" => openclaw_mcp_server::Transport::Stdio,
                "sse" => openclaw_mcp_server::Transport::Sse { host, port },
                other => anyhow::bail!("Unknown transport: {}", other),
            };
            openclaw_mcp_server::run(transport).await?;
        }

        Commands::Navigate { url, format } => {
            info!(url = %url, format = %format, "Navigating");
            let config = openclaw_browser_core::BrowserConfig::default();
            let session = openclaw_browser_core::BrowserSession::launch(config).await?;
            let tab_id = session.new_tab(&url).await?;
            let tab = session.active_tab().await?;

            match format.as_str() {
                "snapshot" => {
                    let snapshot = tab.snapshot().await?;
                    println!("{}", snapshot.to_agent_text());
                }
                "markdown" => {
                    let html = tab.page_source().await?;
                    let content = openclaw_content_extract::extract(&html, &url)?;
                    println!("{}", content.markdown);
                }
                "json" => {
                    let snapshot = tab.snapshot().await?;
                    println!("{}", serde_json::to_string_pretty(&snapshot)?);
                }
                _ => anyhow::bail!("Unknown format: {}", format),
            }

            session.shutdown().await?;
        }

        Commands::Task { description, url, max_steps } => {
            info!(task = %description, "Running autonomous task");
            // TODO: Initialize agent with LLM backend and run task
            println!("Task execution not yet implemented. Task: {}", description);
        }

        Commands::Search { query, max_results } => {
            info!(query = %query, "Searching");
            let results = openclaw_search::search(&query, max_results).await?;
            for (i, result) in results.iter().enumerate() {
                println!("{}. {} — {}", i + 1, result.title, result.url);
                println!("   {}\n", result.snippet);
            }
            if results.is_empty() {
                println!("No results (search providers not yet implemented)");
            }
        }

        Commands::Extract { url, max_tokens } => {
            info!(url = %url, "Extracting content");
            let config = openclaw_browser_core::BrowserConfig::default();
            let session = openclaw_browser_core::BrowserSession::launch(config).await?;
            let _tab_id = session.new_tab(&url).await?;
            let tab = session.active_tab().await?;
            let html = tab.page_source().await?;
            let content = openclaw_content_extract::extract_budgeted(&html, &url, max_tokens)?;
            println!("# {}\n", content.title);
            println!("{}", content.markdown);
            println!("\n---\nTokens: ~{} | Links: {} | Confidence: {:.0}%",
                content.estimated_tokens, content.links.len(), content.confidence * 100.0);
            session.shutdown().await?;
        }
    }

    info!("OpenClaw Browser shutting down cleanly");
    Ok(())
}
