# 🦀 OpenClaw Browser

**An AI-agent-first web browser written in Rust — designed for LLM control, not humans.**

[![License: AGPL-3.0](https://img.shields.io/badge/License-AGPL--3.0-blue.svg)](LICENSE)
[![Rust](https://img.shields.io/badge/rust-1.75%2B-orange.svg)](https://www.rust-lang.org/)
[![GitHub Sponsors](https://img.shields.io/badge/Sponsor-❤-ea4aaa.svg)](https://github.com/sponsors/suhteevah)

---

> **The first native Rust browser built from the ground up for AI agent control.**

OpenClaw Browser is not another browser automation wrapper. It's a purpose-built tool for AI agents that need to navigate the web autonomously — with optimized DOM snapshots, token-efficient content extraction, integrated search, and native MCP support for Claude Code.

## Why This Exists

Every existing AI browser tool falls into one of two categories:

1. **Python wrappers around Playwright/Selenium** — slow, memory-hungry, fragile
2. **Rust CDP clients** — fast but just remote-control Chrome with no AI-specific affordances

OpenClaw Browser is **category 3**: a Rust-native browser toolkit where every component is designed for AI agent consumption. DOM snapshots output flat element lists with ref IDs instead of HTML trees. Content extraction outputs token-budgeted markdown instead of raw pages. Search is built-in. MCP is first-class.

## Architecture

```
┌──────────────────────────────────────────────────────┐
│                    CLI / MCP Server                   │
│              (openclaw-browser, stdio/SSE)            │
├──────────────────────────────────────────────────────┤
│                    Agent Loop                         │
│         observe → think → act (pluggable LLM)        │
├──────────┬──────────┬──────────┬────────────────────┤
│ Browser  │ Content  │ Search   │ Identity            │
│ Core     │ Extract  │ Engine   │ (vault, fingerprint │
│ (CDP)    │ (reader) │ (tantivy)│  auth, stealth)     │
├──────────┴──────────┴──────────┴────────────────────┤
│               Knowledge Store (Cache)                 │
│     SQLite + Tantivy + Blob Store + Adaptive TTLs     │
├──────────────────────────────────────────────────────┤
│               Chrome/Chromium (headless)              │
└──────────────────────────────────────────────────────┘
```

## Crates

| Crate | Description |
|-------|-------------|
| `openclaw-browser-core` | CDP browser control, DOM snapshots, action execution |
| `openclaw-content-extract` | Readability + HTML→Markdown conversion for LLMs |
| `openclaw-cache` | Persistent AI knowledge store: SQLite + Tantivy, adaptive TTLs, compressed blob storage |
| `openclaw-identity` | Encrypted credential vault (AES-256-GCM), browser fingerprint capture/spoofing, auth flows |
| `openclaw-search` | Web metasearch + local Tantivy index |
| `openclaw-agent-loop` | Observe→Think→Act cycle with pluggable LLM backends |
| `openclaw-mcp-server` | MCP server for Claude Code / Cursor / any MCP client |
| `openclaw-browser` (CLI) | Command-line interface and main binary |

## Quick Start

```bash
# Clone and build
git clone https://github.com/suhteevah/openclaw-browser.git
cd openclaw-browser
cargo build --release

# Run as MCP server for Claude Code
./target/release/openclaw-browser serve --transport stdio

# Navigate and get a DOM snapshot
./target/release/openclaw-browser navigate https://example.com

# Extract content as markdown
./target/release/openclaw-browser extract https://example.com --max-tokens 4000

# Run an autonomous browsing task
./target/release/openclaw-browser task "Find the pricing page for Anthropic and extract the tier names"

# Web search
./target/release/openclaw-browser search "Rust browser automation 2026"
```

## Claude Code Integration

Add to your Claude Code MCP config (`~/.claude/mcp_servers.json`):

```json
{
  "openclaw-browser": {
    "command": "/path/to/openclaw-browser",
    "args": ["serve", "--transport", "stdio"]
  }
}
```

Then in Claude Code:
```
> Use openclaw-browser to navigate to github.com/suhteevah and extract the README
```

## MCP Tools

| Tool | Description |
|------|-------------|
| `browse_navigate` | Navigate to URL, return DOM snapshot |
| `browse_click` | Click element by @ref ID |
| `browse_fill` | Fill form field |
| `browse_snapshot` | Get current page state |
| `browse_extract` | Extract content as markdown |
| `browse_screenshot` | Capture page screenshot |
| `browse_search` | Web metasearch |
| `browse_eval_js` | Execute JavaScript |
| `browse_tabs` | List open tabs |
| `browse_task` | Run autonomous browsing task |

## DOM Snapshot Format

Instead of raw HTML (thousands of tokens), agents receive compact snapshots:

```
Page: "GitHub - openclaw-browser" (https://github.com/suhteevah/openclaw-browser)

@e1  [link]      "Code"
@e2  [link]      "Issues (3)"
@e3  [button]    "Star"
@e4  [input]     placeholder="Go to file"
@e5  [link]      "README.md"
@e6  [text]      "An AI-agent-first web browser written in Rust"
```

Agents use ref IDs for actions: `click @e3`, `fill @e4 "main.rs"`

## Security — No .env Files, Ever

Credentials are stored in an **encrypted vault** at `~/.openclaw/vault.db`:

- Master passphrase → argon2id → AES-256-GCM per credential
- Secrets wrapped in `SecretString` (zeroized from memory on drop)
- Vault file permissions: 0600 (owner-only)
- Every credential access logged in audit table
- Human-in-the-loop for CAPTCHAs, passkeys, SMS codes

```bash
# Store a credential
openclaw-browser vault store --domain github.com --kind password --identity matt@example.com

# Capture your real browser fingerprint (launches Chrome briefly)
openclaw-browser fingerprint capture --name "My Chrome"

# All subsequent headless browsing spoofs your real fingerprint
```

## Docs

| File | Purpose |
|------|---------|
| `SOUL.md` | Agent personality + project context for Claude Code |
| `HANDOFF.md` | Step-by-step implementation guide with priorities |
| `BLUEPRINT.md` | God-tier feature roadmap with competitive analysis |
| `CONTRIBUTING.md` | How to contribute |

## Contributing

This is a FOSS project under AGPL-3.0. Contributions welcome! See [CONTRIBUTING.md](CONTRIBUTING.md).

## Support the Project

If OpenClaw Browser saves you time or makes your AI workflows better:

- ⭐ **Star this repo** — it helps with visibility
- 💖 **[Sponsor on GitHub](https://github.com/sponsors/suhteevah)** — fund continued development
- 🐛 **File issues** — bug reports and feature requests are gold

## License

AGPL-3.0 — see [LICENSE](LICENSE) for details.

Built by [Matt Gates](https://github.com/suhteevah) / [Ridge Cell Repair LLC](https://ridgecellrepair.com)
as part of the [OpenClaw](https://github.com/suhteevah) AI infrastructure project.
